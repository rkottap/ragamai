
import streamlit as st
import pandas as pd
import sys
import os
import plotly.express as px
import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from data_preprocessing import preprocess_data, handle_outliers, split_data, label_encode
from model_training import get_model, load_models, prepare_input
from model_evaluation import evaluate_model, modal_compare
import visualization as vis
from Predictions import Predictions


if "X_train" not in st.session_state:
    df = pd.read_csv("data/California_Hospital_Assigned_ZIP.csv")
    df = preprocess_data(df)
    df = handle_outliers(df, ["Risk Adjuested Mortality Rate", "# of Deaths", "# of Cases", "Mortality_Per_Case"])
    df = label_encode(df)

    st.session_state.df = df
    X_train, X_test, y_train, y_test = split_data(df)
    st.session_state.X_train = X_train
    st.session_state.X_test = X_test
    st.session_state.y_train = y_train
    st.session_state.y_test = y_test

if "models" not in st.session_state:
    st.session_state.models = load_models()

if "predictor" not in st.session_state:
    st.session_state.predictor = Predictions(
        dataset_path="data/California_Hospital_Assigned_ZIP.csv",
        model_path="models/mortality_risk_model.pkl"
    )

predictor = st.session_state.predictor


def home_page():
    st.title("🏥 Hospital Ratings Prediction App")
    st.markdown("""
    Welcome! This app allows you to:
    - **Explore the dataset** with Exploratory Data Analysis (EDA).
    - **Train and evaluate machine learning models** for hospital ratings.
    - **Predict mortality rates** for medical procedures.
    - **Recommend top hospitals** based on procedures.
    - **Cluster hospitals** based on geographic location.
    """)

    if st.button("Go to EDA"):
        st.session_state.page = "EDA"
    if st.button("Go to Model Evaluation"):
        st.session_state.page = "Model Evaluation"
    if st.button("Go to Model Comparison Metrics"):
        st.session_state.page = "Model Comparison Metrics"
    if st.button("Go to Prediction & Recommendation"):
        st.session_state.page = "Prediction & Recommendation"


def eda_page():
    if st.button("Back to Home"):
        st.session_state.page = "Home"

    st.title("📊 Exploratory Data Analysis (EDA)")
    df = st.session_state.df

    vis.plot_feature_distribution(df)
    vis.plot_correlation_matrix(df)
    vis.plot_target_distribution(df)
    vis.plot_boxplot_by_rating(df)
    vis.plot_top_counties(df)
    vis.plot_top_hospitals(df)


def model_evaluation_page():
    if st.button("Back to Home"):
        st.session_state.page = "Home"

    st.title("🛠️ Model and Prediction")

    tab1, tab2 = st.tabs(["📈 Model Evaluation", "🏥 Predict Hospital Rating"])

    with tab1:
        st.subheader("Model Evaluation")

        model_choice = st.selectbox(
            "Select a Model for Evaluation",
            [
                "Random Forest (Original)", "XGBoost (Original)", "KNN (Original)", "SVM (Original)",
                "Random Forest (SMOTE)", "XGBoost (SMOTE)", "KNN (SMOTE)", "SVM (SMOTE)"
            ]
        )

        model = get_model(model_choice, st.session_state.models)
        if model:
            X_test = st.session_state.X_test
            y_test = st.session_state.y_test
            evaluate_model(model, X_test, y_test, model_choice)

    with tab2:
        st.subheader("🏥 Predict Hospital Rating")

        model_choice_pred = st.selectbox(
            "Select a Model for Prediction",
            [
                "Random Forest (Original)", "XGBoost (Original)", "KNN (Original)", "SVM (Original)",
                "Random Forest (SMOTE)", "XGBoost (SMOTE)", "KNN (SMOTE)", "SVM (SMOTE)"
            ]
        )

        model_pred = get_model(model_choice_pred, st.session_state.models)

        hospital_names = predictor.df["HOSPITAL"].dropna().unique()
        procedure_names = predictor.df["Procedure/Condition"].dropna().unique()

        selected_hospital = st.selectbox("Select Hospital Name", sorted(hospital_names))
        selected_procedure = st.selectbox("Select Procedure Name", sorted(procedure_names))

        if st.button("Predict Hospital Rating"):
            if selected_hospital and selected_procedure:
                input_features = prepare_input(selected_hospital, selected_procedure, model_pred)
                predicted_rating = model_pred.predict(input_features)[0]
                st.success(f"Predicted Hospital Rating: **{predicted_rating}**")
            else:
                st.error("Please select both Hospital Name and Procedure Name.")



def model_comparison_page():
    if st.button("Back to Home"):
        st.session_state.page = "Home"

    st.title("📈 Model Comparison Metrics")
    metrics_all = modal_compare()
    st.write(metrics_all)


def prediction_and_recommendation_page():
    if st.button("Back to Home"):
        st.session_state.page = "Home"

    st.title("🧠 Prediction & Recommendation")

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "Recommend Good Hospitals",
        "Predict Mortality Rate",
        "High-Risk Procedure Check",
        "Hospital Clustering",
        "Model Evaluation"
    ])

    with tab1:
        st.subheader("🏥 Recommend Good Hospitals")
        procedure = st.selectbox("Select Procedure", predictor.df["Procedure/Condition"].dropna().unique())
        county = st.selectbox("Select County (Optional)", [""] + list(predictor.df["COUNTY"].dropna().unique()))
        top_n = st.slider("Top N Hospitals", 1, 10, 5)

        if st.button("Find Hospitals"):
            result = predictor.recommend_hospitals(procedure, county if county else None, top_n)
            st.dataframe(result)

    with tab2:
        st.subheader("📉 Predict Mortality Rate")
        procedure = st.selectbox("Select Procedure for Prediction", predictor.df["Procedure/Condition"].dropna().unique(), key="predict_proc")

        if st.button("Predict Mortality"):
            predicted_risk = predictor.predict_mortality_rate(procedure)
            st.success(f"Predicted Mortality Rate: {predicted_risk:.2f}%")

    with tab3:
        st.subheader("⚠️ Check Risk Percentage (Real Data)")
        procedure = st.selectbox("Select Procedure for Risk Check", predictor.df["Procedure/Condition"].dropna().unique(), key="risk_check_proc")

        if st.button("Check Risk"):
            real_risk = predictor.get_risk_percentage(procedure)
            st.info(f"Real Data Risk Percentage: {real_risk:.2f}%")


    with tab4:
        st.subheader("Hospital Clustering")
        n_clusters = st.slider("Select number of clusters", 2, 10, 5)

        if st.button("Cluster Hospitals"):
            cluster_result = predictor.perform_kmeans_clustering(n_clusters)

            cluster_result["LATITUDE"] += np.random.normal(0, 0.01, size=len(cluster_result))
            cluster_result["LONGITUDE"] += np.random.normal(0, 0.01, size=len(cluster_result))

            fig = px.scatter_geo(
                cluster_result,
                lat="LATITUDE",
                lon="LONGITUDE",
                color="Cluster",
                hover_name="HOSPITAL",
                title="Hospital Clusters in California",
                projection="natural earth"
            )

            fig.update_geos(
                center=dict(lat=37.5, lon=-119.5),
                projection_scale= 6, 
                fitbounds="locations" 
            )

            st.plotly_chart(fig, use_container_width=True)

    with tab5:
        st.subheader("📈 Model Evaluation")

        if st.button("Evaluate Mortality Risk Model"):
            with st.spinner("Evaluating model..."):
                try:
                    results = predictor.evaluate_model()
                    st.success("Model Evaluation Completed!")

                    st.write(f"**R² Score:** {results['R2 Score']:.4f}")
                    st.write(f"**Mean Absolute Error (MAE):** {results['Mean Absolute Error (MAE)']:.4f}")
                    st.write(f"**Root Mean Squared Error (RMSE):** {results['Root Mean Squared Error (RMSE)']:.4f}")
                except Exception as e:
                    st.error(f"Error during evaluation: {str(e)}")


if "page" not in st.session_state:
    st.session_state.page = "Home"

if st.session_state.page == "Home":
    home_page()
elif st.session_state.page == "EDA":
    eda_page()
elif st.session_state.page == "Model Evaluation":
    model_evaluation_page()
elif st.session_state.page == "Model Comparison Metrics":
    model_comparison_page()
elif st.session_state.page == "Prediction & Recommendation":
    prediction_and_recommendation_page()
