import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

def load_data(file_path):
    df = pd.read_csv(file_path)
    return df

def preprocess_data(df):
    df = df[df['HOSPITAL'] != 'STATEWIDE']
    df.replace({'.': np.nan, ' ': np.nan, '': np.nan}, inplace=True)
    df = df[df['Hospital Ratings'].notna()]
    df.drop(columns=["LONGITUDE", "LATITUDE", "OSHPDID", "ZIP_ASSIGNED"], errors="ignore", inplace=True)

    df["Risk Adjuested Mortality Rate"] = pd.to_numeric(df["Risk Adjuested Mortality Rate"], errors="coerce")
    df['Risk Adjuested Mortality Rate'] = df.groupby('HOSPITAL')['Risk Adjuested Mortality Rate'].transform(lambda x: x.fillna(x.median()))
    
    df["# of Deaths"] = pd.to_numeric(df["# of Deaths"], errors="coerce")
    df["# of Cases"] = pd.to_numeric(df["# of Cases"], errors="coerce")
    df["HOSPITAL"].fillna("Unknown", inplace=True)
    df["COUNTY"].fillna("Unknown", inplace=True)
    df["Procedure/Condition"] = df.groupby("HOSPITAL")["Procedure/Condition"].transform(lambda x: x.fillna(x.mode()[0]))

    df['Mortality_Per_Case'] = df['Risk Adjuested Mortality Rate'] / df['# of Cases']
    df["Mortality_Per_Case"] = pd.to_numeric(df["Mortality_Per_Case"], errors="coerce")

    le_proc = LabelEncoder()
    df["Procedure/Condition"] = le_proc.fit_transform(df["Procedure/Condition"])

    return df

def preprocess_data2(df):
    df = df[df['HOSPITAL'] != 'STATEWIDE'].copy()

    df.replace({'.': np.nan, ' ': np.nan, '': np.nan}, inplace=True)
    df = df[df['Hospital Ratings'].notna()]
    df.drop(columns=["OSHPDID"], errors="ignore", inplace=True)

    df["Risk Adjuested Mortality Rate"] = pd.to_numeric(df["Risk Adjuested Mortality Rate"], errors="coerce")
    df['Risk Adjuested Mortality Rate'] = df.groupby('HOSPITAL')['Risk Adjuested Mortality Rate'].transform(lambda x: x.fillna(x.median()))
    
    df["# of Deaths"] = pd.to_numeric(df["# of Deaths"], errors="coerce")
    df["# of Cases"] = pd.to_numeric(df["# of Cases"], errors="coerce")
    df["HOSPITAL"] = df["HOSPITAL"].fillna("Unknown")
    df["COUNTY"] = df["COUNTY"].fillna("Unknown")

    df["Procedure/Condition"] = df.groupby("HOSPITAL")["Procedure/Condition"].transform(lambda x: x.fillna(x.mode()[0]))

    df['Mortality_Per_Case'] = df['Risk Adjuested Mortality Rate'] / df['# of Cases']
    df["Mortality_Per_Case"] = pd.to_numeric(df["Mortality_Per_Case"], errors="coerce")

    return df

def label_encode(df):
    le_proc = LabelEncoder()
    le_hosp = LabelEncoder()
    le_county = LabelEncoder()
    le_rating = LabelEncoder()

    df["HOSPITAL"] = le_hosp.fit_transform(df["HOSPITAL"])
    df["COUNTY"] = le_county.fit_transform(df["COUNTY"])

    custom_label_map = {'Worse': 0, 'As Expected': 1, 'Better': 2}
    df["Hospital Ratings"] = df["Hospital Ratings"].map(custom_label_map)
    return df


def handle_outliers(df, columns):
    for col in columns:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    return df

def split_data(df):
    X = df.drop(columns=["Hospital Ratings"])
    y = df["Hospital Ratings"]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

    return X_train, X_test, y_train, y_test

