import joblib
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
import pandas as pd

def train_random_forest(X, y):
    model = RandomForestClassifier(random_state=42)
    model.fit(X, y)
    return model

def train_xgboost(X, y):
    model = XGBClassifier(use_label_encoder=False, eval_metric='mlogloss', random_state=42)
    model.fit(X, y)
    return model

def train_knn(X, y):
    model = KNeighborsClassifier()
    model.fit(X, y)
    return model

def train_svm(X, y):
    model = SVC(probability=True, random_state=42)
    model.fit(X, y)
    return model


def save_model(model, file_name):
    joblib.dump(model, file_name)
    print(f"{file_name} saved successfully!")

def train_and_save_models(X_train_orig, y_train_orig, X_train_smote, y_train_smote):
    models = {
        'rf_orig': train_random_forest(X_train_orig, y_train_orig),
        'xgb_orig': train_xgboost(X_train_orig, y_train_orig),
        'knn_orig': train_knn(X_train_orig, y_train_orig),
        'svm_orig': train_svm(X_train_orig, y_train_orig),
        'rf_smote': train_random_forest(X_train_smote, y_train_smote),
        'xgb_smote': train_xgboost(X_train_smote, y_train_smote),
        'knn_smote': train_knn(X_train_smote, y_train_smote),
        'svm_smote': train_svm(X_train_smote, y_train_smote),
    }


    for model_name, model in models.items():
        save_model(model, f'{model_name}.pkl')

def load_models():
    models = {
        'rf_orig': joblib.load('models/rf_model_original.pkl'),
        'xgb_orig': joblib.load('models/xgb_model_original.pkl'),
        'knn_orig': joblib.load('models/knn_model_original.pkl'),
        'svm_orig': joblib.load('models/svm_model_original.pkl'),
        'rf_smote': joblib.load('models/rf_model_smote.pkl'),
        'xgb_smote': joblib.load('models/xgb_model_smote.pkl'),
        'knn_smote': joblib.load('models/knn_model_smote.pkl'),
        'svm_smote': joblib.load('models/svm_model_smote.pkl')
    }
    return models


def get_model(model_choice, models):

    models_dict = {
        "Random Forest (Original)": 'rf_orig',
        "XGBoost (Original)": 'xgb_orig',
        "KNN (Original)": 'knn_orig',
        "SVM (Original)": 'svm_orig',
        "Random Forest (SMOTE)": 'rf_smote',
        "XGBoost (SMOTE)": 'xgb_smote',
        "KNN (SMOTE)": 'knn_smote',
        "SVM (SMOTE)": 'svm_smote'
    }


    model_key = models_dict.get(model_choice, None)

    if model_key:
        return models.get(model_key, None)
    else:
        return None
    
def prepare_input(hospital_name, procedure_name, model):
    feature_names = model.feature_names_in_ if hasattr(model, "feature_names_in_") else model.get_booster().feature_names
    input_df = pd.DataFrame(0, index=[0], columns=feature_names)

    if hospital_name in input_df.columns:
        input_df[hospital_name] = 1
    if procedure_name in input_df.columns:
        input_df[procedure_name] = 1

    return input_df


