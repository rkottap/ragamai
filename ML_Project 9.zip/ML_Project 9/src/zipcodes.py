import pandas as pd

hospital_df = pd.read_csv('data/California Hospital Inpatient Mortality Rates and Quality Ratings .csv')
zip_county_df = pd.read_csv('data/ZIP-COUNTY-FIPS_2017-06.csv')

zip_county_df['COUNTYNAME'] = zip_county_df['COUNTYNAME'].str.replace('County', '', case=False).str.strip().str.lower()
hospital_df['COUNTY'] = hospital_df['COUNTY'].str.strip().str.lower()

zip_county_ca = zip_county_df[zip_county_df['STATE'] == 'CA']
hospital_unique = hospital_df[['COUNTY', 'HOSPITAL']].drop_duplicates()
hospital_unique = hospital_unique[hospital_unique['COUNTY'] != 'aaaa']

assigned_zips = []

for county, group in hospital_unique.groupby('COUNTY'):
    county_zips = zip_county_ca[zip_county_ca['COUNTYNAME'] == county]['ZIP'].tolist()
    if not county_zips:
        assigned_zips.extend([None] * len(group))
    else:
        repeated_zips = (county_zips * ((len(group) // len(county_zips)) + 1))[:len(group)]
        assigned_zips.extend(repeated_zips)

hospital_unique['ZIP_ASSIGNED'] = assigned_zips
hospital_final = hospital_df.merge(hospital_unique, on=['COUNTY', 'HOSPITAL'], how='left')
hospital_final.to_csv('data/California_Hospital_Assigned_ZIP.csv', index=False)
