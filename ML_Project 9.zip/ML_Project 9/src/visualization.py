import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st

def plot_feature_distribution(df):
    st.subheader("Feature Distribution")
    fig, ax = plt.subplots()
    sns.histplot(df['Risk Adjuested Mortality Rate'], kde=True, ax=ax)
    st.pyplot(fig)

def plot_correlation_matrix(df):
    st.subheader("Correlation Matrix")
    fig, ax = plt.subplots()
    corr = df.corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
    st.pyplot(fig)

def plot_target_distribution(df):
    st.subheader("Hospital Ratings Distribution")
    fig, ax = plt.subplots()
    sns.countplot(data=df, x="Hospital Ratings", ax=ax)
    st.pyplot(fig)

def plot_boxplot_by_rating(df):
    st.subheader("Boxplot by Hospital Ratings")
    fig, ax = plt.subplots(figsize=(7, 5))
    sns.boxplot(x=df["Hospital Ratings"], y=df["# of Cases"], palette="Blues_d", ax=ax)
    ax.set_title("Distribution of Cases by Hospital Ratings")
    ax.set_xlabel("Hospital Ratings")
    ax.set_ylabel("Number of Cases")
    st.pyplot(fig)

def plot_top_counties(df):
    st.subheader("Top 10 Counties by Case Count")
    top_counties = df.groupby("COUNTY")["# of Cases"].sum().sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x=top_counties.values, y=top_counties.index, palette="viridis", ax=ax)
    ax.set_title("Top 10 Counties by Case Count")
    ax.set_xlabel("Total Cases")
    ax.set_ylabel("County")
    st.pyplot(fig)

def plot_top_hospitals(df):
    st.subheader("Top 10 Hospitals by Case Count")
    top_hospitals = df.groupby("HOSPITAL")["# of Cases"].sum().sort_values(ascending=False).head(10)
    fig, ax = plt.subplots(figsize=(10, 6))    
    sns.barplot(x=top_hospitals.values, y=top_hospitals.index, palette="mako", ax=ax)
    ax.set_title("Top 10 Hospitals by Case Count")
    ax.set_xlabel("Total Cases")
    ax.set_ylabel("Hospital")
    st.pyplot(fig)

def plot_boxplot_by_rating(df):
    st.subheader("Mortality Rate by Hospital Ratings")
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.boxplot(data=df, x='Hospital Ratings', y='Risk Adjuested Mortality Rate', ax=ax)
    ax.set_title("Mortality Rate by Hospital Ratings")
    ax.set_xlabel("Hospital Rating")
    ax.set_ylabel("Risk Adjusted Mortality Rate")
    st.pyplot(fig)
