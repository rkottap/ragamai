# src/Predictions.py

import pandas as pd
import joblib
from sklearn.cluster import KMeans
from data_preprocessing import preprocess_data2
import streamlit as st
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from data_preprocessing import load_data, preprocess_data, handle_outliers
import numpy as np

class Predictions:
    def __init__(self, dataset_path: str, model_path: str = None):
        self.df = pd.read_csv(dataset_path)
        
        if model_path:
            checkpoint = joblib.load(model_path)
            self.model = checkpoint["model"]
            self.columns = checkpoint["columns"]
        else:
            self.model = None
            self.columns = None
    
    def perform_kmeans_clustering(self, n_clusters: int = 5):

        self.df = preprocess_data2(self.df)
        subset = self.df.dropna(subset=["LATITUDE", "LONGITUDE"])

        subset["LATITUDE"] = pd.to_numeric(subset["LATITUDE"], errors="coerce")
        subset["LONGITUDE"] = pd.to_numeric(subset["LONGITUDE"], errors="coerce")
        subset = subset.dropna(subset=["LATITUDE", "LONGITUDE"])

        subset = subset.reset_index(drop=True)
        X = subset[["LATITUDE", "LONGITUDE"]]
        model = KMeans(n_clusters=n_clusters, random_state=42)
        subset["Cluster"] = model.fit_predict(X)

        return subset


    def recommend_hospitals(self, procedure: str, county: str = None, top_n: int = 5):
        st.write("Procedure user selected:", procedure)
        
        self.df["Procedure/Condition"] = self.df["Procedure/Condition"].str.strip().str.lower()
        procedure = procedure.strip().lower()

        filtered = self.df[
            (self.df["Procedure/Condition"].str.contains(procedure, case=False, na=False)) &
            (self.df["Hospital Ratings"].isin(["As Expected", "Better"]))
        ]

        if county:
            county = county.strip().lower()
            self.df["COUNTY"] = self.df["COUNTY"].str.strip().str.lower()
            filtered = filtered[filtered["COUNTY"] == county]

        return filtered.sort_values(by="Risk Adjuested Mortality Rate").head(top_n)


    def get_risk_percentage(self, procedure: str) -> float:
        filtered = self.df[self.df["Procedure/Condition"] == procedure]
        filtered["Risk Adjuested Mortality Rate"] = pd.to_numeric(
            filtered["Risk Adjuested Mortality Rate"], errors="coerce"
        )
        avg_risk = filtered["Risk Adjuested Mortality Rate"].mean()
        return avg_risk

    def predict_mortality_rate(self, procedure: str) -> float:
        if not self.model or not self.columns:
            raise ValueError("Model or Columns not loaded. Please provide model_path during initialization.")
        
        sample = pd.get_dummies(pd.Series([procedure]))
        sample = sample.reindex(columns=self.columns, fill_value=0)

        predicted_risk = self.model.predict(sample)[0]
        return predicted_risk
    

    def evaluate_model(self):
        """
        Evaluate the regression model using R², MAE, and RMSE.
        """

        if not self.model or not self.columns:
            raise ValueError("Model or Columns not loaded properly.")

        df_eval = self.df.copy()

        df_eval = preprocess_data(df_eval)
        df_eval = handle_outliers(df_eval, ["Risk Adjuested Mortality Rate", "# of Deaths", "# of Cases"])
        
        procedure_features = pd.get_dummies(df_eval["Procedure/Condition"])
        numeric_features = df_eval[["# of Deaths", "# of Cases"]]
        numeric_features = numeric_features.apply(pd.to_numeric, errors="coerce").fillna(0)

        X = pd.concat([procedure_features, numeric_features], axis=1)
        X = X.reindex(columns=self.columns, fill_value=0)
        X.columns = X.columns.astype(str)

        y = pd.to_numeric(df_eval["Risk Adjuested Mortality Rate"], errors="coerce")

        X = X.dropna()
        y = y.loc[X.index]

        predictions = self.model.predict(X)

        from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
        r2 = r2_score(y, predictions)
        mae = mean_absolute_error(y, predictions)
        mse = mean_squared_error(y, predictions)
        rmse = np.sqrt(mse)

        return {
            "R2 Score": r2,
            "Mean Absolute Error (MAE)": mae,
            "Root Mean Squared Error (RMSE)": rmse
        }
