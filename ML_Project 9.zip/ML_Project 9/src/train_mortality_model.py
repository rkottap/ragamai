import pandas as pd
import os
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from data_preprocessing import load_data, preprocess_data, handle_outliers

def train_mortality_model(
    data_path="data/California_Hospital_Assigned_ZIP.csv",
    save_path="models/mortality_risk_model.pkl"
):

    df = load_data(data_path)
    df = preprocess_data(df)
    df = handle_outliers(df, ["Risk Adjuested Mortality Rate", "# of Deaths", "# of Cases"])

    df = df.dropna(subset=["Procedure/Condition", "Risk Adjuested Mortality Rate"])

    X = pd.get_dummies(df["Procedure/Condition"])
    y = pd.to_numeric(df["Risk Adjuested Mortality Rate"], errors="coerce")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    joblib.dump(
        {
            "model": model,
            "columns": X_train.columns.tolist()
        },
        save_path
    )

    print(f"Mortality Risk Model saved at {save_path}")
    print(f"Train R² Score: {model.score(X_train, y_train):.4f}")
    print(f"Test R² Score: {model.score(X_test, y_test):.4f}")

if __name__ == "__main__":
    train_mortality_model()
