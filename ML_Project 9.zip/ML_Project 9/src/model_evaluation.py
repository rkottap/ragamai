from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score, roc_curve, auc, log_loss
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import streamlit as st

def evaluate_model(model, X_test, y_test, model_name="Model"):
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test) if hasattr(model, "predict_proba") else None
    st.write(f"Evaluating {model_name}...")
    st.write(f"Accuracy: {accuracy_score(y_test, y_pred)}")
    st.write(f"Precision: {precision_score(y_test, y_pred, average='macro')}")
    st.write(f"Recall: {recall_score(y_test, y_pred, average='macro')}")
    st.write(f"F1 Score : {f1_score(y_test, y_pred, average='macro')}")
    if y_prob is not None:
        st.write(f"ROC-AUC: {roc_auc_score(y_test, y_prob, multi_class='ovo', average='macro')}")
        st.write(f"Log Loss: {log_loss(y_test, y_prob)}")
    plot_confusion_matrix(y_test, y_pred)
    if y_prob is not None:
        plot_roc_curve(y_test, y_prob)

def plot_confusion_matrix(y_true, y_pred, title="Confusion Matrix"):
    cm = confusion_matrix(y_true, y_pred)
    
    fig, ax = plt.subplots(figsize=(6, 5))

    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, 
                xticklabels=["Worse", "As Expected", "Better"], 
                yticklabels=["Worse", "As Expected", "Better"], ax=ax)
    
    ax.set_title(title)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    
    st.pyplot(fig)

def plot_roc_curve(y_true, y_prob, title="ROC-AUC Curve"):

    y_prob_class_1 = y_prob[:, 1]

    fpr, tpr, thresholds = roc_curve(y_true, y_prob_class_1, pos_label=1)
    roc_auc = auc(fpr, tpr)

    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(fpr, tpr, color="b", lw=2, label=f"ROC curve (area = {roc_auc:.2f})")
    ax.plot([0, 1], [0, 1], color="gray", linestyle="--")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title(title)
    ax.legend(loc="lower right")

    st.pyplot(fig)

def modal_compare(): 
    metrics_orig = [
        {
            "Model": "Random Forest (Original)",
            "Accuracy": 0.987322,
            "Precision": 0.979566,
            "Recall": 0.869022,
            "F1 Score ": 0.917880,
            "MAE": 0.012678,
            "MSE": 0.012678,
            "RMSE": 0.112595,
            "MAPE": 0.094386,
            "ROC-AUC": 0.996863,
            "Log Loss": 0.048855,
            "R-squared": 0.787531
        },
        {
            "Model": "XGBoost (Original)",
            "Accuracy": 0.991091,
            "Precision": 0.968930,
            "Recall": 0.932568,
            "F1 Score ": 0.952020,
            "MAE": 0.008090,
            "MSE": 0.008090,
            "RMSE": 0.094386,
            "MAPE": 0.008090,
            "ROC-AUC": 0.998762,
            "Log Loss": 0.027313,
            "R-squared": 0.850698
        },
        {
            "Model": "KNN (Original)",
            "Accuracy": 0.939866,
            "Precision": 0.617511,
            "Recall": 0.411663,
            "F1 Score ": 0.450745,
            "MAE": 0.060476,
            "MSE": 0.061162,
            "RMSE": 0.247390,
            "MAPE": "inf",
            "ROC-AUC": 0.865517,
            "Log Loss": 0.495861,
            "R-squared": -0.025017
        },
        {
            "Model": "SVM (Original)",
            "Accuracy": 0.940084,
            "Precision": 0.313346,
            "Recall": 0.333333,
            "F1 Score ": 0.323031,
            "MAE": 0.014717,
            "MSE": 0.013334,
            "RMSE": 0.115559,
            "MAPE": 0.115559,
            "ROC-AUC": 0.540120,
            "Log Loss": 1.162723,
            "R-squared": -0.004919
        }
    ]

    metrics_smote = [
        {
            "Model": "Random Forest (SMOTE)",
            "Accuracy": 0.986466,
            "Precision": 0.921968,
            "Recall": 0.952807,
            "F1 Score ": 0.935917,
            "MAE": 0.013534,
            "MSE": 0.013534,
            "RMSE": 0.116337,
            "MAPE": "inf",
            "ROC-AUC": 0.993869,
            "Log Loss": 0.086729,
            "R-squared": 0.773175
        },
        {
            "Model": "XGBoost (SMOTE)",
            "Accuracy": 0.975158,
            "Precision": 0.838795,
            "Recall": 0.931741,
            "F1 Score ": 0.874964,
            "MAE": 0.025013,
            "MSE": 0.025053,
            "RMSE": 0.159234,
            "MAPE": "inf",
            "ROC-AUC": 0.992764,
            "Log Loss": 0.080711,
            "R-squared": 0.850698
        },
        {
            "Model": "KNN (SMOTE)",
            "Accuracy": 0.868083,
            "Precision": 0.516060,
            "Recall": 0.830767,
            "F1 Score ": 0.585802,
            "MAE": 0.132945,
            "MSE": 0.132945,
            "RMSE": 0.367425,
            "MAPE": "inf",
            "ROC-AUC": 0.899372,
            "Log Loss": 1.266048,
            "R-squared": 0.575603
        },
        {
            "Model": "SVM (SMOTE)",
            "Accuracy": 0.617612,
            "Precision": 0.398739,
            "Recall": 0.699808,
            "F1 Score ": 0.375301,
            "MAE": 0.388898,
            "MSE": 0.401919,
            "RMSE": 0.633971,
            "MAPE": "inf",
            "ROC-AUC": 0.844654,
            "Log Loss": 0.847338,
            "R-squared": -5.735828
        }
    ]

    # Convert to DataFrame for easier table display
    metrics_all = pd.DataFrame(metrics_orig + metrics_smote)

    return metrics_all

